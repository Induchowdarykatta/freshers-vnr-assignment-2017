package com.rubicon.hotel.main;

public class RestaurentMgmt {
	
	
	public static void main(String a[]){
	}
	
	public void displayMenu(){
		
	}


}
