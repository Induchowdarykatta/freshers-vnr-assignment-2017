package com.rubicon.hotel.main;

import java.util.ArrayList;
import java.util.Iterator;

import com.rubicon.hotel.domain.Customer;
import com.rubicon.hotel.domain.MenuItem;
import com.rubicon.hotel.domain.Order;
import com.rubicon.hotel.fecilities.Fecilities;
import com.rubicon.hotel.role.BusBoy;
import com.rubicon.hotel.role.ExecutiveChef;
import com.rubicon.hotel.role.Host;
import com.rubicon.hotel.role.Manager;
import com.rubicon.hotel.role.Server;


public class HController {
	 static ArrayList<MenuItem> menuItemArry = new ArrayList<>();
	

	 public HController(){
		 
		 MenuItem dosa =  new MenuItem(1,"Dosa",10, (byte)1);
		 MenuItem idli =  new MenuItem(2,"IDLI",10, (byte)2);
		 MenuItem lunch =  new MenuItem(3,"lunch",20, (byte)3);
		 MenuItem dinner =  new MenuItem(4,"Dinner",100, (byte)4);
		 MenuItem buffet =  new MenuItem(5,"Buffet",150, (byte)5);
		 
		 menuItemArry.add(dosa);
		 menuItemArry.add(idli);
		 menuItemArry.add(dinner);
		 menuItemArry.add(lunch);
		 menuItemArry.add(buffet);
		 
	 }
	
	
	 private void showMenuList()
	 {
	        Iterator<MenuItem> it = menuItemArry.iterator();
	        
	        while (it.hasNext()) {
	            MenuItem re = (MenuItem)it.next();
	             byte menuType = re.getType();
	             String strMenuType;
	            switch( menuType)
	            {
	                case MenuItem.MAIN:
	                strMenuType = "Main";
	                break;
	                case MenuItem.DRINK:
	                strMenuType = "Drink";
	                break;
	                case MenuItem.DESSERT:
	                strMenuType = "Dessert";
	                break;
	                default:
	                strMenuType = "Undefined";
	                break;
	            }
	            String output = String.format("Menu ID:%4d  Name:%-10s  Price:%10.2f Type:%s",
	                                            re.getID(),re.getName(),re.getPrice(),strMenuType);
	            
	            
	            System.out.println(output);
	            
	        }
	 }
	 
	 
	 public static void main(String as[]){
		 HController controller =  new HController();
		 Fecilities fecilities = new Fecilities();
		 Manager manager = new  Manager();
		 Host host = new Host();
		 
		 controller.showMenuList();
		 fecilities.showAvailability();
		 Customer customer = host.recieveCustomer();
		 host.allotTabble(customer);
		 BusBoy boy = new BusBoy(customer);
		 Order order  = manager.takeOrders(customer, menuItemArry);
		 ExecutiveChef chef = new ExecutiveChef(order);
		// chef.recieveOrders();
		// chef.assignOrder();
		 Server server = new Server(order, customer);
		 server.serveFoodCustomers();
		 manager.prepareBill(customer, order);
		 
	 }
}
