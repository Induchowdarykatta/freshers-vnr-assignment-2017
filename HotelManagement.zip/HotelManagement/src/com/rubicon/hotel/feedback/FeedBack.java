package com.rubicon.hotel.feedback;

/*
 * Feedback system where customer complaints and feedback comments are stored
 * */

public class FeedBack {
	
	//complaints/feedback

}
