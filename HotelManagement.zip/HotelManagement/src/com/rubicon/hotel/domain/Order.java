package com.rubicon.hotel.domain;

import java.util.ArrayList;
import java.util.Iterator;

public class Order
{
    final public static int ORDER_CLOSED = 1;
    final public static int ORDER_CANCELED = 2;
    
    private int orderID;
    private String customerID;
    private String date;
    private double total;
    private ArrayList<OrderDetail> orderDetailList = new ArrayList<OrderDetail>();

    /**
     * Constructor for objects of class Order
     */
    public Order(int orderID, String customerID)
    {
        this.orderID = orderID;
        this.customerID = customerID;
    }
    public ArrayList<OrderDetail> getOrderDetail()
    {
        return this.orderDetailList;
    }
  
    public int getOrderID() {
		return orderID;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public void addItem(OrderDetail detail)
	{
	   orderDetailList.add(detail);
	}
    
    public boolean deleteItem(int index)
    {
        try
        {
            orderDetailList.remove(index);
            calculateTotal();
            return true;
        }
        catch(Exception e)
        {
            //System.out.println(e.toString()  + ":" + e.getMessage());
             return false;
        }
    }
    
    public void  calculateTotal()
    {
       total = 0;
        OrderDetail re;
         Iterator<OrderDetail> it = orderDetailList.iterator();
         while (it.hasNext()) {
            re = it.next();
            total += re.getTotalPrice();
        }
    }
}
